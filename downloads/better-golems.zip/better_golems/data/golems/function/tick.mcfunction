effect give @e[type=iron_golem] speed infinite 1 true
execute as @e[type=snow_golem] run attribute @s minecraft:generic.max_health base set 100
effect give @e[type=snow_golem] regeneration infinite 1 true
effect give @e[type=snow_golem] fire_resistance infinite 1 true
execute at @e[type=villager] run effect give @e[type=iron_golem,distance=..5] regeneration 5 2 true