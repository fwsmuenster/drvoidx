execute as @a at @s run execute if block ~ ~-1 ~ minecraft:red_concrete run effect give @s minecraft:jump_boost 2 1 true
execute as @a at @s run execute if block ~ ~-1 ~ minecraft:blue_concrete run effect give @s minecraft:speed 2 1 true
execute as @a at @s run execute if block ~ ~-1 ~ minecraft:sea_lantern run kill @s
execute as @a at @s run execute if block ~ ~-1 ~ minecraft:gold_block run spawnpoint @s ~ ~ ~
execute as @a at @s run execute if block ~ ~-1 ~ minecraft:yellow_concrete run effect give @s minecraft:levitation 3 2 true
execute as @a at @s run execute if block ~ ~2 ~ minecraft:lime_concrete run effect give @s minecraft:levitation 1 1 true


