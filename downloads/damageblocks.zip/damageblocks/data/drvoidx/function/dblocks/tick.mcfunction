execute as @a at @s run function drvoidx:dblocks/allplayers
